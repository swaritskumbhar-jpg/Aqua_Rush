import React, { useState, useEffect } from 'react';

export default function TrackingMap() {
  const [riderX, setRiderX] = useState(15);

  useEffect(() => {
    const interval = setInterval(() => {
      setRiderX(prev => Math.min(prev + Math.random() * 12 + 6, 78));
    }, 1200);
    return () => clearInterval(interval);
  }, []);

  const eta = Math.round(((78 - riderX) / 78) * 20);

  return (
    <div className="relative h-52 bg-gradient-to-r from-emerald-100 via-sky-100 to-blue-100 rounded-3xl overflow-hidden border">
      {/* Store */}
      <div className="absolute left-6 top-1/2 -translate-y-1/2 text-center">
        <div className="text-3xl">🏪</div>
        <div className="text-[10px] font-medium text-emerald-700 mt-0.5">STORE</div>
      </div>

      {/* Home */}
      <div className="absolute right-6 top-1/2 -translate-y-1/2 text-center">
        <div className="text-3xl">🏠</div>
        <div className="text-[10px] font-medium text-blue-700 mt-0.5">HOME</div>
      </div>

      {/* Rider */}
      <div 
        className="absolute top-1/2 -translate-y-1/2 transition-all duration-1000" 
        style={{ left: `${riderX}%` }}
      >
        <div className="text-4xl -mt-1">🏍️</div>
        <div className="text-xs text-center text-red-600 font-medium -mt-1">RIDER</div>
      </div>

      {/* Footer bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-slate-900 text-white text-xs py-2.5 px-4 flex items-center justify-between rounded-b-3xl">
        <div>Suresh K. • Moving</div>
        <div className="font-mono">ETA: {eta} min</div>
      </div>
    </div>
  );
}