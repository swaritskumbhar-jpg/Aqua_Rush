import React, { createContext, useContext, useReducer, useEffect } from 'react';

const AppContext = createContext();

const initialState = {
  prices: {
    '500ml': 20,
    '1L': 40,
    '2L': 70,
    '5L': 120,
    '20L': 200,
  },
  depositPerBottle: 50,
  bottleOwned: { '500ml': 0, '1L': 0, '2L': 0, '5L': 0, '20L': 0 },
  orders: [
    {
      id: 'ORD-001',
      buyer: 'Sneha Joshi',
      phone: '9876543210',
      address: 'Flat 12, Sunrise Apartments, Koregaon Park, Pune',
      items: [{ size: '20L', qty: 2 }],
      total: 400,
      deposit: 100,
      status: 'pending',
      riderId: null,
      createdAt: new Date(Date.now() - 10000000).toISOString(),
    },
    {
      id: 'ORD-002',
      buyer: 'Rahul Sharma',
      phone: '9123456780',
      address: 'House 45, MG Road, Pune',
      items: [{ size: '5L', qty: 3 }],
      total: 360,
      deposit: 50,
      status: 'accepted',
      riderId: 'r1',
      createdAt: new Date(Date.now() - 8000000).toISOString(),
    },
    {
      id: 'ORD-003',
      buyer: 'Priya Patel',
      phone: '9988776655',
      address: 'B-203, Blue Ridge, Hinjewadi, Pune',
      items: [{ size: '1L', qty: 6 }],
      total: 240,
      deposit: 0,
      status: 'picked',
      riderId: 'r2',
      createdAt: new Date(Date.now() - 5000000).toISOString(),
    },
    {
      id: 'ORD-004',
      buyer: 'Amit Kumar',
      phone: '9871234560',
      address: 'Shop 7, Camp Area, Pune',
      items: [{ size: '2L', qty: 4 }],
      total: 280,
      deposit: 50,
      status: 'delivered',
      riderId: 'r1',
      createdAt: new Date(Date.now() - 2000000).toISOString(),
    },
  ],
  riders: [
    { id: 'r1', name: 'Suresh K.', status: 'online', activeOrders: 1, earnings: 320 },
    { id: 'r2', name: 'Raju D.', status: 'online', activeOrders: 1, earnings: 180 },
    { id: 'r3', name: 'Mohan V.', status: 'offline', activeOrders: 0, earnings: 95 },
  ],
  cart: { '500ml': 0, '1L': 0, '2L': 0, '5L': 0, '20L': 0 },
  buyerProfile: { name: 'Sneha Joshi', phone: '9876543210', address: 'Flat 12, Sunrise Apartments, Koregaon Park, Pune' },
  notifications: [],
  currentRole: 'buyer',
};

function reducer(state, action) {
  switch (action.type) {
    case 'UPDATE_PRICE':
      return {
        ...state,
        prices: { ...state.prices, [action.size]: action.price },
      };
    case 'UPDATE_DEPOSIT_RATE':
      return { ...state, depositPerBottle: action.value };
    case 'SET_CART_QTY':
      return {
        ...state,
        cart: { ...state.cart, [action.size]: Math.max(0, action.qty) },
      };
    case 'PLACE_ORDER':
      const newOrder = {
        id: `ORD-${String(state.orders.length + 1).padStart(3, '0')}`,
        ...action.payload,
        status: 'pending',
        riderId: null,
        createdAt: new Date().toISOString(),
      };
      return {
        ...state,
        orders: [...state.orders, newOrder],
        cart: { '500ml': 0, '1L': 0, '2L': 0, '5L': 0, '20L': 0 },
      };
    case 'UPDATE_ORDER_STATUS':
      return {
        ...state,
        orders: state.orders.map(order =>
          order.id === action.id ? { ...order, status: action.status } : order
        ),
      };
    case 'ASSIGN_RIDER':
      return {
        ...state,
        orders: state.orders.map(order =>
          order.id === action.orderId ? { ...order, riderId: action.riderId, status: 'accepted' } : order
        ),
      };
    case 'ADD_NOTIFICATION':
      return {
        ...state,
        notifications: [...state.notifications, action.notification],
      };
    case 'DISMISS_NOTIFICATION':
      return {
        ...state,
        notifications: state.notifications.filter(n => n.id !== action.id),
      };
    case 'SET_ROLE':
      return { ...state, currentRole: action.role };
    default:
      return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  // Auto-dismiss notifications
  useEffect(() => {
    if (state.notifications.length > 0) {
      const timer = setTimeout(() => {
        dispatch({ type: 'DISMISS_NOTIFICATION', id: state.notifications[0].id });
      }, 4500);
      return () => clearTimeout(timer);
    }
  }, [state.notifications]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);