import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Plus, Minus, MapPin, Clock } from 'lucide-react';
import TrackingMap from '../components/TrackingMap';

const bottleSizes = ['500ml', '1L', '2L', '5L', '20L'];
const emojis = { '500ml': '🥤', '1L': '💧', '2L': '🫗', '5L': '🪣', '20L': '🚰' };

export default function BuyerView() {
  const { state, dispatch } = useApp();
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [orderForm, setOrderForm] = useState({ ...state.buyerProfile });
  const [showTracking, setShowTracking] = useState(false);
  const [currentOrder, setCurrentOrder] = useState(null);

  const cartItems = Object.entries(state.cart).filter(([_, qty]) => qty > 0);

  const calculateTotals = () => {
    let itemTotal = 0;
    let depositTotal = 0;

    cartItems.forEach(([size, qty]) => {
      const price = state.prices[size];
      itemTotal += price * qty;

      const owned = state.bottleOwned[size] || 0;
      const newBottles = Math.max(0, qty - owned);
      depositTotal += newBottles * state.depositPerBottle;
    });

    return { itemTotal, depositTotal, grandTotal: itemTotal + depositTotal };
  };

  const { itemTotal, depositTotal, grandTotal } = calculateTotals();

  const updateCart = (size, qty) => {
    dispatch({ type: 'SET_CART_QTY', size, qty });
  };

  const placeOrder = () => {
    if (cartItems.length === 0) return;

    const orderItems = cartItems.map(([size, qty]) => ({ size, qty }));
    const payload = {
      buyer: orderForm.name,
      phone: orderForm.phone,
      address: orderForm.address,
      items: orderItems,
      total: itemTotal,
      deposit: depositTotal,
    };

    dispatch({ type: 'PLACE_ORDER', payload });
    dispatch({
      type: 'ADD_NOTIFICATION',
      notification: { id: Date.now(), message: 'Order placed successfully!', type: 'success' }
    });

    setShowOrderModal(false);
    setShowTracking(true);
    setCurrentOrder(payload);
    // Reset cart
    Object.keys(state.cart).forEach(size => dispatch({ type: 'SET_CART_QTY', size, qty: 0 }));
  };

  return (
    <div className="p-4 pb-20">
      <div className="mb-6">
        <h1 className="text-3xl font-semibold tracking-tight">Order Water</h1>
        <p className="text-gray-500">Fresh delivery in Pune • 30 mins</p>
      </div>

      {/* Bottle Grid */}
      <div className="grid grid-cols-2 gap-3 mb-8">
        {bottleSizes.map(size => (
          <div key={size} className="bg-white rounded-3xl p-4 border">
            <div className="text-4xl mb-2">{emojis[size]}</div>
            <div className="font-medium">{size}</div>
            <div className="text-sky-600 font-semibold text-lg">₹{state.prices[size]}</div>
            <div className="text-xs text-gray-500 mt-0.5">per bottle</div>

            <div className="flex items-center justify-between mt-4">
              <button onClick={() => updateCart(size, Math.max(0, state.cart[size] - 1))} className="w-9 h-9 rounded-2xl border flex items-center justify-center active:bg-gray-100">
                <Minus className="w-4 h-4" />
              </button>
              <span className="font-mono text-xl tabular-nums w-8 text-center">{state.cart[size]}</span>
              <button onClick={() => updateCart(size, state.cart[size] + 1)} className="w-9 h-9 rounded-2xl border flex items-center justify-center active:bg-gray-100">
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Cart Summary */}
      {cartItems.length > 0 && (
        <div className="bg-white rounded-3xl p-5 mb-6 border sticky bottom-4 shadow-xl">
          <div className="flex justify-between text-sm mb-3">
            <span>Items</span>
            <span>₹{itemTotal}</span>
          </div>
          <div className="flex justify-between text-sm mb-3 text-amber-600">
            <span>Deposit (refundable)</span>
            <span>₹{depositTotal}</span>
          </div>
          <div className="border-t pt-3 flex justify-between font-semibold">
            <span>Total</span>
            <span>₹{grandTotal}</span>
          </div>

          <button
            onClick={() => setShowOrderModal(true)}
            className="mt-4 w-full bg-sky-500 hover:bg-sky-600 active:bg-sky-700 text-white py-3.5 rounded-2xl font-medium"
          >
            Place Order • ₹{grandTotal}
          </button>
        </div>
      )}

      {/* Order History */}
      <div className="mt-8">
        <div className="font-medium mb-3 px-1">Recent Orders</div>
        {state.orders.slice(0, 3).map(order => (
          <div key={order.id} className="bg-white rounded-2xl p-4 mb-2 border flex justify-between items-center">
            <div>
              <div className="font-mono text-xs text-gray-400">{order.id}</div>
              <div>{order.items.map(i => `${i.qty}×${i.size}`).join(', ')}</div>
            </div>
            <div className="text-right">
              <div className="font-semibold">₹{order.total + order.deposit}</div>
              <div className="text-xs capitalize px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 inline-block mt-0.5">{order.status}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Order Modal */}
      {showOrderModal && (
        <div className="fixed inset-0 bg-black/60 flex items-end z-50">
          <div className="bg-white w-full rounded-t-3xl p-6">
            <h3 className="font-semibold text-xl mb-5">Delivery Details</h3>
            <input type="text" value={orderForm.name} onChange={e => setOrderForm({ ...orderForm, name: e.target.value })} placeholder="Full Name" className="w-full mb-3 px-4 py-3 border rounded-2xl" />
            <input type="tel" value={orderForm.phone} onChange={e => setOrderForm({ ...orderForm, phone: e.target.value })} placeholder="Phone Number" className="w-full mb-3 px-4 py-3 border rounded-2xl" />
            <textarea value={orderForm.address} onChange={e => setOrderForm({ ...orderForm, address: e.target.value })} placeholder="Full Address" rows={3} className="w-full mb-6 px-4 py-3 border rounded-2xl resize-none" />
            
            <div className="flex gap-3">
              <button onClick={() => setShowOrderModal(false)} className="flex-1 py-3.5 border rounded-2xl">Cancel</button>
              <button onClick={placeOrder} className="flex-1 py-3.5 bg-sky-500 text-white rounded-2xl">Confirm &amp; Pay</button>
            </div>
          </div>
        </div>
      )}

      {/* Tracking */}
      {showTracking && currentOrder && (
        <div className="fixed inset-0 bg-black/60 z-[60] flex items-end">
          <div className="bg-white w-full rounded-t-3xl p-6 pb-10">
            <div className="flex justify-between mb-4">
              <div>
                <div className="font-semibold">Order #{currentOrder.id || 'ORD-005'}</div>
                <div className="text-green-600 flex items-center gap-1 text-sm"><Clock className="w-4 h-4" /> ETA: 18 mins</div>
              </div>
              <button onClick={() => setShowTracking(false)} className="text-sm text-gray-500">Close</button>
            </div>
            <TrackingMap />
          </div>
        </div>
      )}
    </div>
  );
}