import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import BuyerView from './screens/BuyerView';
import RiderView from './screens/RiderView';
import AdminView from './screens/AdminView';
import { Truck, User, Settings } from 'lucide-react';

function AppContent() {
  const { state, dispatch } = useApp();
  const [role, setRole] = useState('buyer');

  const handleRoleChange = (newRole) => {
    setRole(newRole);
    dispatch({ type: 'SET_ROLE', role: newRole });
  };

  const renderView = () => {
    switch (role) {
      case 'buyer':
        return <BuyerView />;
      case 'rider':
        return <RiderView />;
      case 'admin':
        return <AdminView />;
      default:
        return <BuyerView />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 max-w-[640px] mx-auto">
      {/* Top Navbar */}
      <nav className="bg-white border-b sticky top-0 z-50">
        <div className="px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-sky-500 rounded-xl flex items-center justify-center">
              <Truck className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="font-semibold text-xl tracking-tight">AquaRush</span>
            </div>
          </div>

          <div className="flex gap-1 bg-gray-100 p-1 rounded-2xl">
            <button
              onClick={() => handleRoleChange('buyer')}
              className={`px-4 py-1.5 text-sm rounded-xl flex items-center gap-1.5 transition-all ${role === 'buyer' ? 'bg-white shadow-sm' : 'text-gray-600'}`}
            >
              <User className="w-4 h-4" /> Buyer
            </button>
            <button
              onClick={() => handleRoleChange('rider')}
              className={`px-4 py-1.5 text-sm rounded-xl flex items-center gap-1.5 transition-all ${role === 'rider' ? 'bg-white shadow-sm' : 'text-gray-600'}`}
            >
              <Truck className="w-4 h-4" /> Rider
            </button>
            <button
              onClick={() => handleRoleChange('admin')}
              className={`px-4 py-1.5 text-sm rounded-xl flex items-center gap-1.5 transition-all ${role === 'admin' ? 'bg-white shadow-sm' : 'text-gray-600'}`}
            >
              <Settings className="w-4 h-4" /> Admin
            </button>
          </div>
        </div>
      </nav>

      {/* Notifications */}
      {state.notifications.length > 0 && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50">
          {state.notifications.map((notif) => (
            <div key={notif.id} className="bg-slate-900 text-white px-4 py-2 rounded-3xl text-sm flex items-center gap-2 shadow-xl mb-2">
              <span className="text-green-400">✓</span> {notif.message}
            </div>
          ))}
        </div>
      )}

      {renderView()}
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;